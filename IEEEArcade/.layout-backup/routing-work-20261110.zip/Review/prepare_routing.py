"""Build conservative multi-layer routing obstacles and jobs from the saved board."""
from pathlib import Path
import pcbnew as p,numpy as np,json,math,struct,collections
from PIL import Image,ImageDraw
ROOT=Path.cwd();OUT=ROOT/'Review';BACK=ROOT/'.layout-backup/before-routing-20261110';b=p.LoadBoard(str(BACK/'IEEEArcade.kicad_pcb'))
STEP=.2;X0=30.;Y0=30.;W=1001;H=626;layers=[p.F_Cu,p.In1_Cu,p.In2_Cu,p.B_Cu]
def grid(x,y):return round((x-X0)/STEP),round((y-Y0)/STEP)
def point(pos):return grid(p.ToMM(pos.x),p.ToMM(pos.y))
netcodes={n.GetNetname():n.GetNetCode() for n in b.GetNetInfo().NetsByNetcode().values()};ground=netcodes['GND']
arr=np.zeros((4,H,W),dtype='<i4');novia=np.zeros((H,W),dtype=np.uint8);regions=np.zeros((H,W),dtype='<i4');padmap=collections.defaultdict(list)
def maskrect(bb,extra=0):
 x1=math.floor((p.ToMM(bb.GetX())-X0-extra)/STEP);y1=math.floor((p.ToMM(bb.GetY())-Y0-extra)/STEP);x2=math.ceil((p.ToMM(bb.GetRight())-X0+extra)/STEP);y2=math.ceil((p.ToMM(bb.GetBottom())-Y0+extra)/STEP)
 return max(0,x1),max(0,y1),min(W-1,x2),min(H-1,y2)
def paint(a,rect,net):
 x1,y1,x2,y2=rect
 if x1>x2 or y1>y2:return
 view=a[y1:y2+1,x1:x2+1];view[(view!=0)&(view!=net)]=-1;view[view==0]=net
for f in b.GetFootprints():
 for pad in f.Pads():
  if not any(pad.IsOnLayer(l) for l in layers):continue
  net=pad.GetNetCode() or -1;rect=maskrect(pad.GetBoundingBox(),0)
  for i,l in enumerate(layers):
   if pad.IsOnLayer(l):paint(arr[i],rect,net)
  a,c,d,e=maskrect(pad.GetBoundingBox(),.38);novia[c:e+1,a:d+1]=1
  # All drilled pads have through barrels; model them on all copper layers.
  if pad.GetDrillSize().x>0:
   for i in range(4):paint(arr[i],rect,net)
  if pad.GetNetCode()>0 and pad.GetNumber():padmap[pad.GetNetCode()].append({'ref':f.GetReference(),'pin':pad.GetNumber(),'xy':point(pad.GetPosition()),'pos':[p.ToMM(pad.GetPosition().x),p.ToMM(pad.GetPosition().y)],'through':pad.GetDrillSize().x>0})
 for z in f.Zones():
  # All current footprint keepouts are axis-aligned rectangles after 90-degree rotations.
  bb=z.GetBoundingBox();rect=maskrect(bb,.03);a,c,d,e=rect
  if z.GetDoNotAllowTracks():
   for i,l in enumerate(layers):
    if z.GetLayerSet().Contains(l):arr[i,c:e+1,a:d+1]=-1
  if z.GetDoNotAllowVias():novia[c:e+1,a:d+1]=1
bus_segments=[([80,48.5],[204,48.5],3.0),([80,48.5],[80,136.5],3.0),([80,136.5],[188,136.5],3.0)]
for ch in range(1,31):
 f=next(f for f in b.GetFootprints() if f.GetReference()==f'J{ch+10}');pad=next(a for a in f.Pads() if a.GetNumber()=='1');pp=[p.ToMM(pad.GetPosition().x),p.ToMM(pad.GetPosition().y)];bus_segments.append((pp,[pp[0],48.5 if ch<=16 else 136.5],1.0))
for a,c,width in bus_segments:
 im=Image.new('1',(W,H));d=ImageDraw.Draw(im);d.line([grid(*a),grid(*c)],fill=1,width=math.ceil(width/STEP)+1);mask=np.asarray(im,dtype=bool);arr[3][mask]=netcodes['+12V']
for i in range(4):arr[i,:3,:]=-1;arr[i,-3:,:]=-1;arr[i,:,:3]=-1;arr[i,:,-3:]=-1
# In2 supply pours are separated by at least 0.5 mm; In1 is a continuous GND plane.
rects={'+12V':[(78,30.6,229.4,59.5),(78,59.5,86,126),(78,126,229.4,154.4)],'+3V3':[(86.5,60,229.4,125.5)],'+5V':[(30.6,30.6,77.5,100)],'+5V_DISPLAY':[(30.6,100.5,77.5,154.4)],'GND':[(30.6,30.6,229.4,154.4)]}
regionboxes={}
for name,rr in rects.items():
 code=netcodes[name];boxes=[]
 for x1,y1,x2,y2 in rr:
  a,c=grid(x1,y1);d,e=grid(x2,y2);boxes.append([a,c,d,e])
  if name!='GND':regions[c:e+1,a:d+1]=code
 regionboxes[code]=boxes
jobs=[];meta={};counter=0
planes=set(netcodes[n] for n in rects)
def addjob(code,pad,target=None,width=.25,kind=0):
 global counter
 counter+=1;id='J'+str(counter);meta[id]={'net':code,'start':pad,'end':target,'width':width,'kind':kind};x,y=pad['xy'];tx,ty=target['xy'] if target else (x,y)
 jobs.append((id,code,x,y,-1 if pad['through'] else 0,tx,ty,-1 if target and target['through'] else 0,kind,width));return id
# Reserve short escape routes at IC signal pins before the longer routes.
for code,pads in padmap.items():
 if code in planes or len(pads)<2:continue
 name=next(n for n,c in netcodes.items() if c==code)
 if name.startswith('unconnected-'):continue
 for pad in pads:
  if pad['ref']=='J3' or (not pad['through'] and (pad['ref'].startswith('U') or pad['ref']=='A1' or (pad['ref'].startswith('R5') and pad['pin']=='2'))):
   addjob(code,pad,width=.25,kind=2)
# Local supplies: surface +12V pads in the buck cluster connect through its front pour.
for code,pads in padmap.items():
 if code not in planes:continue
 name=next(n for n,c in netcodes.items() if c==code)
 for pad in pads:
  if pad['through']:continue
  if name=='+12V':continue
  addjob(code,pad,width=.4 if name not in ['GND'] else .3,kind=1)
# Via bridges between the buck VIN pour and the wide internal +12V bus.
for x,y in [(78.8,54),(78.8,65),(78.8,75),(78.8,84)]:addjob(netcodes['+12V'],{'ref':'VIN_POUR','pin':'','xy':grid(x,y),'pos':[x,y],'through':False},width=1.,kind=1)
# MST pad links; route small local loops first, then long signal buses.
links=[]
for code,pads in padmap.items():
 if len(pads)<2:continue
 name=next(n for n,c in netcodes.items() if c==code)
 if code in planes and name not in ['+3V3','+5V_DISPLAY']:continue
 if name.startswith('unconnected-'):continue
 remaining=list(range(1,len(pads)));connected=[0]
 while remaining:
  dist,i,j=min(((pads[i]['pos'][0]-pads[j]['pos'][0])**2+(pads[i]['pos'][1]-pads[j]['pos'][1])**2,i,j) for i in connected for j in remaining)
  width=.6 if name in ['+3V3','+5V_DISPLAY'] else 3. if name=='Net-(F1-Pad1)' else .8 if name=='Net-(A1-VSYS)' else .5 if any(p['ref'].startswith('J') and p['pin']=='2' for p in pads) else .25
  links.append((dist,code,pads[i],pads[j],width));remaining.remove(j);connected.append(j)
for dist,code,a,c,width in sorted(links,key=lambda x:(0 if x[1] in [netcodes['+3V3'],netcodes['+5V_DISPLAY']] else 1 if x[1] in [netcodes['DISP_R1_5V'],netcodes['DISP_B1_5V']] else 2,x[0])):addjob(code,a,c,width=width)
# Write binary input for the local C# pathfinder.
def iw(f,v):f.write(struct.pack('<i',v))
def string(f,s):
 data=s.encode();n=len(data)
 while n>=128:f.write(bytes([(n&127)|128]));n>>=7
 f.write(bytes([n]));f.write(data)
with (OUT/'routing-grid.bin').open('wb') as f:
 iw(f,W);iw(f,H);f.write(struct.pack('<d',STEP));iw(f,ground);f.write(arr.tobytes());f.write(novia.tobytes());f.write(regions.tobytes());iw(f,len(regionboxes))
 for net,rr in regionboxes.items():
  iw(f,net);iw(f,len(rr))
  for rect in rr:
   for v in rect:iw(f,v)
 iw(f,len(jobs))
 for id,code,x,y,l,tx,ty,tl,kind,width in jobs:
  string(f,id)
  for n in [code,x,y,l,tx,ty,tl,kind]:iw(f,n)
  f.write(struct.pack('<d',width))
(OUT/'routing-jobs.json').write_text(json.dumps({'step':STEP,'origin':[X0,Y0],'jobs':meta,'plane_rectangles':rects,'netcodes':netcodes,'bus_segments':bus_segments},indent=2))
print('Prepared',len(jobs),'jobs;',sum(1 for j in jobs if j[-2]==1),'plane connections;',len(links),'signal links')

