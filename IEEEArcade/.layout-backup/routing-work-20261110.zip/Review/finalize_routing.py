from pathlib import Path
import pcbnew as p,json,math,re,os,sys
sys.path.insert(0,'Review');from schematic_tools import parse
root=Path.cwd();file=root/'IEEEArcade.kicad_pcb';tmp=root/'Review/routing-finalizing.kicad_pcb';b=p.LoadBoard(str(file));changes=[];replacements={}
for z in b.Zones():
 if not z.IsTeardropArea() and z.GetNetname()=='+5V_DISPLAY':z.SetPadConnection(p.ZONE_CONNECTION_FULL)
a=next(f for f in b.GetFootprints() if f.GetReference()=='A1');theta=math.radians(a.GetOrientationDegrees());fx,fy=p.ToMM(a.GetPosition().x),p.ToMM(a.GetPosition().y)
for pad in a.Pads():
 id=pad.m_Uuid.AsString()
 if id not in ['7d7869e9-604c-46d1-ac04-1a448586cfb0','b2ad243a-f597-4ae9-9008-9496f32c37fe']:continue
 assert not pad.GetNumber() and pad.GetShape()==p.PAD_SHAPE_RECT and pad.IsOnLayer(p.F_Paste) and not pad.IsOnLayer(p.F_Cu)
 bb=pad.GetBoundingBox();corners=[]
 for x in [p.ToMM(bb.GetX()),p.ToMM(bb.GetRight())]:
  for y in [p.ToMM(bb.GetY()),p.ToMM(bb.GetBottom())]:
   dx,dy=x-fx,y-fy;corners.append((round(math.cos(theta)*dx-math.sin(theta)*dy,6),round(math.sin(theta)*dx+math.cos(theta)*dy,6)))
 xmin=min(x for x,y in corners);xmax=max(x for x,y in corners);ymin=min(y for x,y in corners);ymax=max(y for x,y in corners)
 replacements[id]=f'(fp_rect (start {xmin} {ymin}) (end {xmax} {ymax}) (stroke (width 0) (type default)) (fill solid) (layer "F.Paste") (uuid "{id}"))'
 changes.append({'action':'paste-only pad converted to equivalent filled paste rectangle','uuid':id,'world_bbox_mm':[p.ToMM(bb.GetX()),p.ToMM(bb.GetY()),p.ToMM(bb.GetRight()),p.ToMM(bb.GetBottom())]})
for t in b.GetTracks():
 if isinstance(t,p.PCB_VIA) or t.GetNetname()!='Net-(U2-SW)':continue
 aa,cc=t.GetStart(),t.GetEnd();xx=[p.ToMM(aa.x),p.ToMM(cc.x)];yy=[p.ToMM(aa.y),p.ToMM(cc.y)]
 if max(xx)<=60.651 and min(yy)>=52.19 and max(yy)<=57.01:t.SetWidth(p.FromMM(.8));changes.append({'action':'SW current-path width increased to 0.8 mm','uuid':t.m_Uuid.AsString()})
assert p.SaveBoard(str(tmp),b);s=tmp.read_text();edits=[]
for id,new in replacements.items():
 j=s.index(id);start=s.rfind('(pad ',0,j);end=s.index('\n\t\t)',j)+5;old=s[start:end];assert parse(old).key()=='pad';edits.append((start,end,new))
for start,end,new in sorted(edits,reverse=True):s=s[:start]+new+s[end:]
tmp.write_text(s,newline='\n');check=p.LoadBoard(str(tmp));assert len(check.GetTracks())==len(b.GetTracks());assert len(check.GetFootprints())==292
# Confirm both replacement shapes retain the actual original paste aperture bounds.
fa=next(f for f in check.GetFootprints() if f.GetReference()=='A1')
for c in changes:
 if 'world_bbox_mm' not in c:continue
 sh=next(sh for sh in fa.GraphicalItems() if sh.m_Uuid.AsString()==c['uuid']);bb=sh.GetBoundingBox();actual=[p.ToMM(bb.GetX()),p.ToMM(bb.GetY()),p.ToMM(bb.GetRight()),p.ToMM(bb.GetBottom())];assert all(abs(x-y)<.001 for x,y in zip(actual,c['world_bbox_mm'])),(actual,c)
os.replace(tmp,file);(root/'Review/routing-cleanup.json').write_text(json.dumps(changes,indent=2)+'\n');print('Atomic save verified;',len(replacements),'paste apertures preserved;',len(changes)-len(replacements),'SW segments widened')
