"""Apply the checked grid routes, supply copper and ground stitching to the backed-up board."""
from pathlib import Path
import pcbnew as p,json,numpy as np,math,collections
ROOT=Path.cwd();OUT=ROOT/'Review';b=p.LoadBoard(str(ROOT/'.layout-backup/before-routing-20261110/IEEEArcade.kicad_pcb'));m=json.loads((OUT/'routing-jobs.json').read_text());layers=[p.F_Cu,p.In1_Cu,p.In2_Cu,p.B_Cu];step=m['step'];x0,y0=m['origin'];nets=m['netcodes'];counts=collections.Counter();trackset=set();viamap={}
def v(x,y):return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
def xy(pt):return (round(x0+step*pt[1],6),round(y0+step*pt[2],6))
def track(a,c,layer,net,width):
 if math.dist(a,c)<.00001:return
 key=(layer,net,width,tuple(sorted([tuple(a),tuple(c)])))
 if key in trackset:return
 trackset.add(key);t=p.PCB_TRACK(b);t.SetStart(v(*a));t.SetEnd(v(*c));t.SetLayer(layer);t.SetWidth(p.FromMM(width));t.SetNetCode(net);t.SetTeardropsEnabled(True);b.Add(t);counts['segments']+=1
 return t
def via(a,net,stitch=False):
 key=tuple(a)
 if key in viamap:
  assert viamap[key]==net,(key,net,viamap[key]);return
 viamap[key]=net;q=p.PCB_VIA(b);q.SetPosition(v(*a));q.SetWidth(p.FromMM(.6));q.SetDrill(p.FromMM(.3));q.SetViaType(p.VIATYPE_THROUGH);q.SetLayerPair(p.F_Cu,p.B_Cu);q.SetNetCode(net);q.SetTeardropsEnabled(True);b.Add(q);counts['stitching_vias' if stitch else 'routing_vias']+=1
ls=(OUT/'routing-paths.txt').read_text().splitlines();i=0;failed=[]
while i<len(ls):
 vals=ls[i].split();i+=1
 if vals[0]=='FAIL':failed.append(vals);continue
 _,id,code,width,kind,n=vals;code=int(code);width=float(width);kind=int(kind);n=int(n);pts=[tuple(map(int,ls[j].split())) for j in range(i,i+n)];i+=n;job=m['jobs'][id]
 if kind==2:continue # Fanout reservations are already included in actual end-to-end paths.
 # Merge collinear grid steps, retaining every turn and layer transition.
 start=pts[0];prev=pts[0];direction=None
 for cur in pts[1:]:
  if cur[0]!=prev[0]:
   track(xy(start),xy(prev),layers[prev[0]],code,width);via(xy(cur),code);start=cur;direction=None
  else:
   d=(cur[1]-prev[1],cur[2]-prev[2])
   if direction is not None and d!=direction:
    track(xy(start),xy(prev),layers[prev[0]],code,width);start=prev
   direction=d
  prev=cur
 track(xy(start),xy(prev),layers[prev[0]],code,width)
 track(job['start']['pos'],xy(pts[0]),layers[pts[0][0]],code,width)
 if kind:via(xy(pts[-1]),code)
 elif job['end']:track(xy(pts[-1]),job['end']['pos'],layers[pts[-1][0]],code,width)
 counts['routed_jobs']+=1
# Preserve a wide lamp supply on the back in addition to its inner-layer pour.
for a,c,width in m['bus_segments']:track(a,c,p.B_Cu,nets['+12V'],width)
# Add ground stitching only where the route grid has clearance on every copper layer.
arr=np.fromfile(OUT/'routing-paths.txt.grid',dtype='<i4').reshape((4,626,1001));raw=(OUT/'routing-grid.bin').read_bytes();offset=4+4+8+4+4*626*1001*4;novia=np.frombuffer(raw[offset:offset+626*1001],dtype=np.uint8).reshape(626,1001);g=nets['GND'];stitches=[]
for xx in range(34,229,10):
 for yy in range(34,154,10):
  x=round((xx-x0)/step);y=round((yy-y0)/step)
  if novia[y,x]:continue
  if any(math.dist((xx,yy),a)<1.0 for a in viamap):continue
  cells=[arr[:,y+dy,x+dx] for dy in range(-4,5) for dx in range(-4,5) if dx*dx+dy*dy<=16]
  if any(np.any((a!=0)&(a!=g)) for a in cells):continue
  via((xx,yy),g,True);stitches.append([xx,yy])
# Copper fills: uninterrupted inner GND, split inner supplies, outer GND and local buck pours.
def zone(name,net,layer,points,priority=0,thermal=True):
 z=p.ZONE(b);z.SetZoneName(name);z.SetLayer(layer);z.SetNetCode(net);z.SetLocalClearance(p.FromMM(.25));z.SetThermalReliefGap(p.FromMM(.3));z.SetThermalReliefSpokeWidth(p.FromMM(.5));z.SetPadConnection(p.ZONE_CONNECTION_FULL if net==nets['+12V'] else p.ZONE_CONNECTION_THT_THERMAL if thermal else p.ZONE_CONNECTION_FULL);z.SetMinThickness(p.FromMM(.2));z.SetAssignedPriority(priority);z.SetIslandRemovalMode(p.ISLAND_REMOVAL_MODE_ALWAYS);poly=z.Outline();poly.NewOutline()
 for x,y in points:poly.Append(p.FromMM(x),p.FromMM(y))
 b.Add(z);counts['copper_zones']+=1;return z
def rect(name,net,layer,rr,priority=0):
 x1,y1,x2,y2=rr;return zone(name,net,layer,[(x1,y1),(x2,y1),(x2,y2),(x1,y2)],priority)
outline=[(30.6,30.6),(229.4,30.6),(229.4,154.4),(30.6,154.4)]
for l in [p.F_Cu,p.In1_Cu,p.B_Cu]:zone('GND reference / stitching',g,l,outline)
zone('12V lamp distribution',nets['+12V'],p.In2_Cu,[(78,30.6),(229.4,30.6),(229.4,59.5),(86,59.5),(86,126),(229.4,126),(229.4,154.4),(78,154.4)],1)
for name in ['+3V3','+5V','+5V_DISPLAY']:rect(name+' distribution',nets[name],p.In2_Cu,m['plane_rectangles'][name][0],1)
rect('Buck local VIN copper',nets['+12V'],p.F_Cu,(48,50,79.4,90),3)
rect('Buck local output copper',nets['+5V'],p.F_Cu,(48,30.6,78,45),3)
for f in b.GetFootprints():
 for pad in f.Pads():
  pad.SetTeardropsEnabled(True)
  if f.GetReference()=='J3' and pad.GetNetname()=='GND':pad.SetLocalZoneConnection(p.ZONE_CONNECTION_FULL)
p.SaveBoard(str(ROOT/'IEEEArcade.kicad_pcb'),b)
counts['failed_jobs']=len(failed);counts['unique_vias']=len(viamap)
(OUT/'routing-application.json').write_text(json.dumps({'counts':dict(counts),'failed':failed,'ground_stitch_positions':stitches},indent=2)+'\n')
print(json.dumps(dict(counts)));print('Failed jobs',failed)
