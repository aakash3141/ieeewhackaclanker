using System;
using System.IO;
using System.Collections.Generic;
public class GridRouter {
 int W,H,N,ground; double step; int[][] copper,center; byte[] noVia; int[] region,viaNets; int[] distance,seen,parent; int epoch=0; int[] offsetsX,offsetsY; int activeNet,rad; double activeWidth; const int MaxCost=2000000000;
 class Heap {
  public List<int> nodes=new List<int>(); public List<int> scores=new List<int>();
  public void Push(int n,int s){int i=nodes.Count;nodes.Add(n);scores.Add(s);while(i>0){int j=(i-1)/2;if(scores[j]<=s)break;nodes[i]=nodes[j];scores[i]=scores[j];i=j;}nodes[i]=n;scores[i]=s;}
  public int Pop(){int n=nodes[0],last=nodes.Count-1,v=nodes[last],s=scores[last];nodes.RemoveAt(last);scores.RemoveAt(last);if(last==0)return n;int i=0;while(i*2+1<last){int j=i*2+1;if(j+1<last&&scores[j+1]<scores[j])j++;if(scores[j]>=s)break;nodes[i]=nodes[j];scores[i]=scores[j];i=j;}nodes[i]=v;scores[i]=s;return n;}
 }
 bool Clear(int x,int y,int l,int radius,bool via){
  if(x<radius+2||x>=W-radius-2||y<radius+2||y>=H-radius-2)return false;
  if(via&&viaNets[y*W+x]==activeNet)return true;
  if(via&&noVia[y*W+x]!=0)return false;
  if(via){for(int vy=-3;vy<=3;vy++)for(int vx=-3;vx<=3;vx++)if(vx*vx+vy*vy<9 && viaNets[(y+vy)*W+x+vx]!=0)return false;}
  if(!via&&center[l][y*W+x]==activeNet)return true;
  for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++){
   if(dx*dx+dy*dy>radius*radius)continue;int k=(y+dy)*W+x+dx;
   if(via){for(int z=0;z<4;z++){int n=copper[z][k];if(n!=0&&n!=activeNet)return false;}}
   else {int n=copper[l][k];if(n!=0&&n!=activeNet)return false;}
  }return true;
 }
 void Paint(int x,int y,int l,int radius,int net){for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++){if(dx*dx+dy*dy>radius*radius)continue;int xx=x+dx,yy=y+dy;if(xx>=0&&xx<W&&yy>=0&&yy<H){int k=yy*W+xx;if(copper[l][k]==0||copper[l][k]==net)copper[l][k]=net;}}}
 int Heur(int x,int y,int tx,int ty){int dx=Math.Abs(tx-x),dy=Math.Abs(ty-y);return 10*Math.Max(dx,dy)+4*Math.Min(dx,dy);}
 int RegionHeur(int x,int y,int net){int best=MaxCost;foreach(int[] box in regions[net]){int xx=Math.Max(box[0],Math.Min(box[2],x));int yy=Math.Max(box[1],Math.Min(box[3],y));best=Math.Min(best,Heur(x,y,xx,yy));}return best;}
 Dictionary<int,List<int[]>> regions=new Dictionary<int,List<int[]>>();
 class Job{public string id;public int net,x,y,l,tx,ty,tl,type;public double width;}
 List<Job> jobs=new List<Job>();StreamWriter output;int routes=0,failed=0,vias=0;
 bool Route(Job j){activeNet=j.net;activeWidth=j.width;rad=(int)Math.Ceiling((.20+j.width/2+.015)/step);int vr=(int)Math.Ceiling((.20+.3+.065)/step);int start=(j.l<0?0:j.l)*N+j.y*W+j.x;
  Heap heap=new Heap();epoch++;seen[start]=epoch;distance[start]=0;parent[start]=-1;heap.Push(start,j.type!=0?(j.type==2?0:RegionHeur(j.x,j.y,j.net)):Heur(j.x,j.y,j.tx,j.ty));if(j.l<0){foreach(int z in new int[]{2,3}){int st=z*N+j.y*W+j.x;seen[st]=epoch;distance[st]=0;parent[st]=-1;heap.Push(st,Heur(j.x,j.y,j.tx,j.ty));}}int end=-1,pops=0;
  int[] dxs={1,-1,0,0,1,1,-1,-1};int[] dys={0,0,1,-1,1,-1,1,-1};
  while(heap.nodes.Count>0&&pops<1800000){int cur=heap.Pop();int l=cur/N,k=cur%N,x=k%W,y=k/W;pops++;
   bool goal=j.type!=0?((j.type==2||j.net==ground||region[k]==j.net)&&Clear(x,y,l,vr,true)):(x==j.tx&&y==j.ty&&(j.tl<0||l==j.tl));
   if(goal){end=cur;break;}
   for(int d=0;d<8;d++){
    int xx=x+dxs[d],yy=y+dys[d];if(xx<1||xx>=W-1||yy<1||yy>=H-1)continue;
    if(!Clear(xx,yy,l,rad,false))continue;
    if(d>=4&&(!Clear(xx,y,l,rad,false)||!Clear(x,yy,l,rad,false)))continue;
    int next=l*N+yy*W+xx;int cost=distance[cur]+(d<4?10:14);
    // Gentle preferred direction per routing layer, without forcing extra bends.
    if((l==0&&dys[d]!=0)||(l==3&&dxs[d]!=0))cost+=1;
    if(seen[next]==epoch&&distance[next]<=cost)continue;seen[next]=epoch;distance[next]=cost;parent[next]=cur;
    int h=j.type!=0?(j.type==2?0:RegionHeur(xx,yy,j.net)):Heur(xx,yy,j.tx,j.ty);heap.Push(next,cost+h);
   }
   if(j.type==0&&((x%2==0&&y%2==0)||viaNets[k]==j.net)&&Clear(x,y,l,vr,true)){
    foreach(int z in new int[]{0,2,3}){if(z==l)continue;int next=z*N+k,cost=distance[cur]+95;if(seen[next]==epoch&&distance[next]<=cost)continue;seen[next]=epoch;distance[next]=cost;parent[next]=cur;heap.Push(next,cost+Heur(x,y,j.tx,j.ty));}
   }
  }
  if(end<0){output.WriteLine("FAIL "+j.id+" "+pops);failed++;return false;}
  List<int> path=new List<int>();for(int n=end;n>=0;n=parent[n])path.Add(n);path.Reverse();
  output.WriteLine("ROUTE "+j.id+" "+j.net+" "+j.width+" "+j.type+" "+path.Count);
  foreach(int n in path){int l=n/N,k=n%N,x=k%W,y=k/W;output.WriteLine(l+" "+x+" "+y);center[l][k]=j.net;Paint(x,y,l,(int)Math.Ceiling((j.width/2+.02)/step),j.net);}
  for(int i=1;i<path.Count;i++)if(path[i]/N!=path[i-1]/N){int k=path[i]%N;viaNets[k]=j.net;for(int z=0;z<4;z++){center[z][k]=j.net;Paint(k%W,k/W,z,2,j.net);}vias++;}
  if(j.type!=0){int k=end%N;viaNets[k]=j.net;for(int z=0;z<4;z++){center[z][k]=j.net;Paint(k%W,k/W,z,2,j.net);}vias++;}
  routes++;return true;
 }
 public void Run(string input,string result){using(BinaryReader r=new BinaryReader(File.OpenRead(input))){W=r.ReadInt32();H=r.ReadInt32();step=r.ReadDouble();ground=r.ReadInt32();N=W*H;copper=new int[4][];for(int l=0;l<4;l++){copper[l]=new int[N];for(int k=0;k<N;k++)copper[l][k]=r.ReadInt32();}noVia=r.ReadBytes(N);region=new int[N];for(int k=0;k<N;k++)region[k]=r.ReadInt32();int nr=r.ReadInt32();for(int t=0;t<nr;t++){int net=r.ReadInt32(),ct=r.ReadInt32();var list=new List<int[]>();for(int q=0;q<ct;q++)list.Add(new int[]{r.ReadInt32(),r.ReadInt32(),r.ReadInt32(),r.ReadInt32()});regions[net]=list;}
 int nj=r.ReadInt32();for(int i=0;i<nj;i++){Job j=new Job();j.id=r.ReadString();j.net=r.ReadInt32();j.x=r.ReadInt32();j.y=r.ReadInt32();j.l=r.ReadInt32();j.tx=r.ReadInt32();j.ty=r.ReadInt32();j.tl=r.ReadInt32();j.type=r.ReadInt32();j.width=r.ReadDouble();jobs.Add(j);}}
  viaNets=new int[N];center=new int[4][];for(int z=0;z<4;z++)center[z]=new int[N];
  distance=new int[4*N];seen=new int[4*N];parent=new int[4*N];output=new StreamWriter(result);List<Job> retry=new List<Job>();int nJob=0;
  foreach(Job j in jobs){if(!Route(j))retry.Add(j);if(++nJob%25==0){output.Flush();Console.WriteLine(nJob+"/"+jobs.Count+" routes="+routes+" failed="+failed+" vias="+vias);}}
  using(BinaryWriter bw=new BinaryWriter(File.Create(result+".grid"))){for(int z=0;z<4;z++)for(int k=0;k<N;k++)bw.Write(copper[z][k]);}
  output.Flush();output.Dispose();Console.WriteLine("DONE "+routes+" "+failed+" "+vias);
 }
 public static void Main(string[] args){new GridRouter().Run(args[0],args[1]);}
}
